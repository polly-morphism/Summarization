from bson import ObjectId
from src.database import mongo_db
from src.tasks import celery
import spacy
import xx_ent_wiki_sm

import nltk
from nltk.corpus import stopwords
from nltk.cluster.util import cosine_distance
from nltk.tokenize import sent_tokenize
import numpy as np
import networkx as nx
import time
import spacy
from spacy_langdetect import LanguageDetector

start_time = time.time()


def get_language(text):
    nlp = spacy.load("xx_ent_wiki_sm")
    nlp.add_pipe(nlp.create_pipe('sentencizer'))
    nlp.add_pipe(LanguageDetector(), name="language_detector", last=True)
    doc = nlp(text)
    return doc._.language


def sentence_similarity(sent1, sent2, stopwords=None):
    if stopwords is None:
        stopwords = []

    sent1 = [w.lower() for w in sent1]
    sent2 = [w.lower() for w in sent2]

    all_words = list(set(sent1 + sent2))

    vector1 = [0] * len(all_words)
    vector2 = [0] * len(all_words)

    # build the vector for the first sentence
    for w in sent1:
        if w in stopwords:
            continue
        vector1[all_words.index(w)] += 1

    # build the vector for the second sentence
    for w in sent2:
        if w in stopwords:
            continue
        vector2[all_words.index(w)] += 1

    return 1 - cosine_distance(vector1, vector2)


def build_similarity_matrix(sentences, stop_words):
    # Create an empty similarity matrix
    similarity_matrix = np.zeros((len(sentences), len(sentences)))

    for idx1 in range(len(sentences)):
        for idx2 in range(len(sentences)):
            if idx1 == idx2:  # ignore if both are same sentences
                continue
            similarity_matrix[idx1][idx2] = sentence_similarity(sentences[idx1], sentences[idx2], stop_words)

    return similarity_matrix


def generate_summary(text, top_n=5):
    nltk.download("stopwords")
    stop_words = stopwords.words('english')
    summarize_text = []

    # Step 1 - Read text anc split it
    sentences = sent_tokenize(text)

    # Step 2 - Generate Similary Martix across sentences
    sentence_similarity_martix = build_similarity_matrix(sentences, stop_words)

    # Step 3 - Rank sentences in similarity martix
    sentence_similarity_graph = nx.from_numpy_array(sentence_similarity_martix)
    scores = nx.pagerank(sentence_similarity_graph)

    # Step 4 - Sort the rank and pick top sentences
    ranked_sentence = sorted(((scores[i], s) for i, s in enumerate(sentences)), reverse=True)
    # print("Indexes of top ranked_sentence order are ", ranked_sentence)

    for i in range(top_n):
        summarize_text.append("".join(ranked_sentence[i][1]))

    # Step 5 - Off course, output the summarize text

    return ". ".join(summarize_text)
    # print("Summarize Text: \n", ". ".join(summarize_text))


women_text = """
            Women education is a catch all term which refers to the state of primary, secondary, tertiary and health 
            education in girls and women. There are 65 Million girls out of school across the globe; majority of them
            are in the developing and underdeveloped countries. All the countries of the world, especially the 
            developing and underdeveloped countries must take necessary steps to improve their condition of female 
            education; as women can play a vital role in the nation’s development.If we consider society as tree, 
            then men are like its strong main stem which supports the tree to face the elements and women are like 
            its roots; most important of them all. The stronger the roots are the bigger and stronger the tree will 
            be spreading its branches; sheltering and protecting the needy.Women are the soul of a society; a society 
            can well be judged by the way its women are treated. An educated man goes out to make the society better,
            while an educated woman; whether she goes out or stays at home, makes the house and its occupants better. 
            Women are the soul of a society; a society can well be judged by the way its women are treated. 
            An educated man goes out to make the society better, while an educated woman; whether she goes out or 
            stays at home, makes the house and its occupants better.Women play many roles in a society- mother, 
            wife, sister, care taker, nurse etc. They are more compassionate towards the needs of others and have a 
            better understanding of social structure. An educated mother will make sure that her children are educated, 
            and will weigh the education of a girl child, same as boys.History is replete with evidences, that 
            the societies in which women were treated equally to men and were educated; prospered and grew socially 
            as well as economically. It will be a mistake to leave women behind in our goal of sustainable development, 
            and it could only be achieved if both the genders are allowed equal opportunities in education and other 
            areas.Education makes women more confident and ambitious; 
            they become more aware of their rights and can raise their voice against exploitation and violence. 
            A society cannot at all progress if its women weep silently. They have to have the weapon of education 
            to carve out a progressive path for their own as well as their families. 
                """
# print(women_text)
# print(generate_summary(women_text, 2))

print("--- %s seconds ---" % (time.time() - start_time))

@celery.task(ignore_result=True, name='named_entities')
def get_summ(document_id: str) -> None:
    nlp = xx_ent_wiki_sm.load()
    target = mongo_db.news.find_one({'_id': ObjectId(document_id)})
    title = target['title']
    content = target['content']
    doc_title = nlp(title)
    doc_content = nlp(content)
