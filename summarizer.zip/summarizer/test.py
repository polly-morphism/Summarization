from summarization.run_summarization import Summarization
from input_reader import Namespace
import torch

summarizer = Summarization()

arguments  = Namespace(alpha=0.95, batch_size=4, beam_size=5, block_trigram=True, compute_rouge=False,\
                            max_length=200, min_length=10, no_cuda=False)
text = "President Trump's defense team on Monday will continue its arguments in the Senate impeachment trial. The team is expected to maintain that the president was legally justified in freezing military assistance to Ukraine and that the case against Trump presented by Democrats does not clear the bar of an impeachable offense.\nThe arguments come a day after a report by The New York Times that Trump directly told his former national security adviser John Bolton that he would hold up aid to Ukraine until the country launched investigations into his political rivals.\nThe military assistance and the desired investigations are at the heart of the impeachment proceedings. Democrats say Trump's actions constitute a clear case of abuse of power, with Trump placing his personal interests over the country's. The legal team representing Trump in the Senate trial argues that the president had justifiable concern about corruption in Ukraine.\nThe aid was ultimately released without the probes."
arguments.max_length = len(text)//2
arguments.text = text
arguments.device = torch.device("cpu")
arguments.finalize()
summary = summarizer.evaluate(args=arguments)
print(summary)
