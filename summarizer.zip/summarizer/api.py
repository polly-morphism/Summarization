from flask import request, Flask, jsonify
from summarization.run_summarization import Summarization
from input_reader import Namespace
import torch

app = Flask(__name__)
summarizer = Summarization()

@app.route('/', methods=['POST'])
def create_task():
    """
    curl -i -H "Content-Type: application/json" -X POST -d '{"text":"His allies have made similar arguments, though not quite so hyperbolic. They said the president has been railroaded based on hearsay evidence. They argued he has been d$
    """
    print(request.json)
    if not request.json or not 'text' in request.json:
        abort(400)
    arguments  = Namespace(alpha=0.95, batch_size=4, beam_size=5, block_trigram=True, compute_rouge=False,\
                           max_length=200, min_length=10, no_cuda=False)
    if "max_length" in request.json:
        try:
            if int(request.json['max_length'])<len(request.json['text'])//2:
            arguments.max_length = request.json['max_length']
    else:
        arguments.max_length = len(request.json['text'])//2
    text = request.json['text']
    arguments.text = text
    arguments.max_length = max_length
    arguments.device = torch.device("cuda")
    arguments.finalize()
    summary = summarizer.evaluate(args=arguments)

    summary = {
        "summary": summary
    }
    return jsonify(summary), 201
